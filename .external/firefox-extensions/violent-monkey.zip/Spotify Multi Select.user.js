// ==UserScript==
// @name        Spotify Multi Select
// @version     0.4
// @description Select multiple songs at once to edit them
// @author      CennoxX
// @contact     cesar.bernard@gmx.de
// @homepage    https://twitter.com/CennoxX
// @namespace   https://greasyfork.org/users/21515
// @match       https://open.spotify.com/*
// @grant       GM.addStyle
// ==/UserScript==
/* jshint esversion: 6 */
(function() {
    'use strict';
    var tracklist;
    var menu;
    var copyAction = false;
    var firstSelectionIndex = -1;
    const ContextAction =
          {
              STARTRADIO: 0,
              TOGGLELOVEDSONG: 1,
              ADDTOQUEUE: 2,
              ADDTOPLAYLIST: 3,
              DELETEFROMPLAYLIST: 4,
              COPYSONGLINK: 5,
              OPENINDESKAPP: 6,
          };
    GM.addStyle(".focus.tracklist-row{background-color: hsla(0,0%,100%,.1)}");
    setInterval(function(){
        tracklist = document.querySelector(".tracklist");
        menu = document.querySelector("nav.react-contextmenu");
        if (menu && tracklist && !tracklist.onclick){
            tracklist.onclick = onTracklistClick;
            menu.onclick = onMenuClick;
        }
    }, 500);
    function onTracklistClick(e) {
        var song = e.target.closest(".tracklist-row");
        if (e.ctrlKey) {
            song.classList.toggle("focus");
        }else if (e.shiftKey) {
            song.classList.toggle("focus");
            var songs = [...tracklist.children];
            var index = songs.indexOf(song.closest(".react-contextmenu-wrapper"));
            if (firstSelectionIndex == -1){
                firstSelectionIndex = index;
            }else{
                var secondSelectionIndex = index;
                if (firstSelectionIndex > secondSelectionIndex){
                    [firstSelectionIndex, secondSelectionIndex] = [secondSelectionIndex, firstSelectionIndex];
                }
                for (var i = ++firstSelectionIndex; i<secondSelectionIndex;i++){
                    songs[i].querySelector(".tracklist-row").classList.toggle("focus");
                }
                firstSelectionIndex = -1;
            }
        }else if (e.target.classList.contains("spoticon-ellipsis-16") && song.classList.contains("focus")){
            song.classList.remove("focus");
        }
    }
    function onMenuClick(e) {
        if (!copyAction){
            var actionText = e.target.innerText;
            var action = [...e.target.parentNode.children].indexOf(e.target);
            if (action==ContextAction.TOGGLELOVEDSONG || action==ContextAction.ADDTOQUEUE || action==ContextAction.DELETEFROMPLAYLIST){
                var track = null;
                var songIndex = document.querySelectorAll('.tracklist-row.focus').length;
                var editSongs = setInterval(function(){
                    songIndex--;
                    track = document.querySelectorAll('.tracklist-row.focus')[songIndex];
                    if (!track){
                        copyAction = false;
                        clearInterval(editSongs);
                    }else{
                        copyAction = true;
                        var e = track.ownerDocument.createEvent('MouseEvents');
                        e.initMouseEvent('contextmenu', true, true, track.ownerDocument.defaultView, 1, 0, 0, 0, 0, false, false, false, false, 2, null);
                        track.dispatchEvent(e);
                        setTimeout(function(){
                            var contextm = document.querySelector("nav.react-contextmenu");
                            var actionTodo = contextm.querySelectorAll(".react-contextmenu-item")[action];
                            if (actionTodo.innerText == actionText){
                                actionTodo.click();
                            }
                            track.classList.remove("focus");
                        },10);
                    }
                },50);
            }
        }
    }
})();