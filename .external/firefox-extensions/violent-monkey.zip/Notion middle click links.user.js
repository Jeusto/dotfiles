// ==UserScript==
// @name        Notion middle click links
// @namespace   Violentmonkey Scripts
// @match       https://www.notion.so/*
// @grant       none
// @version     1.0
// @author      -
// @description 03/05/2022, 13:30:56
// @icon        https://img.icons8.com/color/344/notion--v1.png
// ==/UserScript==

(function() {
  window.addEventListener('load', function() {
    function waitForElm(selector) {
      return new Promise(resolve => {
        if (document.querySelector(selector)) {
          return resolve(document.querySelector(selector));
        }

        const observer = new MutationObserver(mutations => {
          if (document.querySelector(selector)) {
            resolve(document.querySelector(selector));
            observer.disconnect();
          }
        });

        observer.observe(document.body, {
          childList: true,
          subtree: true
        });
      });
    }

    waitForElm('.notion-link-token').then((elm) => {
      let elements = document.getElementsByClassName("notion-link-token");


      for (let i = 0; i < elements.length; i++) {
        elements[i].addEventListener('auxclick', function(e) {
          if (e.which == 2) {
            e.preventDefault();
            window.open(this.getAttribute("href"));
          }
        });
      }
    });


  }, false);
})();